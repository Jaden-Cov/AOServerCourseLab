<html>

<head>
    <title>Hello World!</title>
</head>

<body>
    <?php echo '<p>My Name is <b>Your Name Here</b></p>'; ?>
    <?php echo '<p>This is run directly from the browser!</p>'; ?>
</body>

</html>